# Cumination

<img src="https://user-images.githubusercontent.com/46063764/103461711-a9eb6280-4d20-11eb-983b-516b022cbbf5.png" width="300" align="right">



Welcome to Cumination!





---
All credit to the fantastic people at reddit who has provided the fixes, and especially jdoedev & 12asdfg12 & camilt


and Whitecream & holisticdioxide who are the original author/s of the addon.

For auto-updates, download repository.dobbelina-1.0.4.zip here: https://dobbelina.github.io  
This is also where you find custom sites.

**Please post in the "Issues" section if you can contribute to fix   
broken sites/catchers, or make a pull request.**

![GitHub closed issues](https://img.shields.io/github/issues-closed/dobbelina/repository.dobbelina)
![GitHub last commit (by committer)](https://img.shields.io/github/last-commit/dobbelina/repository.dobbelina)
[![Latest Version](https://img.shields.io/badge/dynamic/xml?color=blue&label=latest%20addon%20version&query=%2Faddon%2F@version&url=https%3A%2F%2Fraw.githubusercontent.com%2Fdobbelina%2Frepository.dobbelina%2Fmaster%2Fplugin.video.cumination%2Faddon.xml)](https://github.com/dobbelina/repository.dobbelina)
<div align="center">

[![Visitors](https://api.visitorbadge.io/api/daily?path=https%3A%2F%2Fgithub.com%2Fdobbelina%2Frepository.dobbelina&label=Visitors%20Today&countColor=%23eca90b&style=flat)](https://visitorbadge.io/status?path=https%3A%2F%2Fgithub.com%2Fdobbelina%2Frepository.dobbelina)

</div>






